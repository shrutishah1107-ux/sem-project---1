


import streamlit as st
import sqlite3
import hashlib

# --------------------------------------------------
# PAGE SETTINGS & DATABASE SETUP
# --------------------------------------------------

st.set_page_config(
    page_title="Smart Village",
    page_icon="🌾",
    layout="wide"
)

DB_FILE = "smart_village.db"

def init_db():
    """Create database tables if they do not exist."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    # Users Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT NOT NULL,
            village TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')
    
    # Resources Table
    c.execute('''
        CREATE TABLE IF NOT EXISTS resources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER NOT NULL,
            owner_name TEXT NOT NULL,
            owner_phone TEXT NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            village TEXT NOT NULL,
            description TEXT NOT NULL,
            status TEXT DEFAULT 'Available',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()

def hash_password(password):
    """Hash password using SHA-256 for security."""
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(name, email, phone, village, password, role):
    """Insert a new user into the database."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute('''
            INSERT INTO users (name, email, phone, village, password, role)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (name, email.lower().strip(), phone, village, hash_password(password), role))
        conn.commit()
        conn.close()
        return True, "Account created successfully! 🎉"
    except sqlite3.IntegrityError:
        conn.close()
        return False, "An account with this email already exists."

def authenticate_user(email, password):
    """Check credentials against the database."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        SELECT id, name, email, phone, role, village FROM users 
        WHERE email = ? AND password = ?
    ''', (email.lower().strip(), hash_password(password)))
    user = c.fetchone()
    conn.close()
    return user

def add_resource(owner_id, owner_name, owner_phone, title, category, village, description):
    """Add a new resource listing to the database."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''
        INSERT INTO resources (owner_id, owner_name, owner_phone, title, category, village, description)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (owner_id, owner_name, owner_phone, title, category, village, description))
    conn.commit()
    conn.close()

def get_resources(category_filter="All", village_filter="All"):
    """Fetch active resource listings with optional filtering."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    query = "SELECT id, title, category, village, description, owner_name, owner_phone, status FROM resources WHERE 1=1"
    params = []
    
    if category_filter != "All":
        query += " AND category = ?"
        params.append(category_filter)
    if village_filter != "All":
        query += " AND village = ?"
        params.append(village_filter)
        
    query += " ORDER BY id DESC"
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    return rows

def delete_resource(resource_id):
    """Delete a resource listing from the database (Admin action)."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM resources WHERE id = ?", (resource_id,))
    conn.commit()
    conn.close()

def get_all_users():
    """Fetch all registered users for Admin panel."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT id, name, email, phone, village, role FROM users ORDER BY id DESC")
    users = c.fetchall()
    conn.close()
    return users

# Initialize database on app startup
init_db()

# --------------------------------------------------
# SESSION STATE
# --------------------------------------------------

if "page" not in st.session_state:
    st.session_state.page = "Home"

if "user" not in st.session_state:
    st.session_state.user = None

# --------------------------------------------------
# FUNCTIONS
# --------------------------------------------------

def go_to(page):
    st.session_state.page = page
    st.rerun()

def logout():
    st.session_state.user = None
    st.session_state.page = "Home"
    st.rerun()

# --------------------------------------------------
# CSS (FIXED FOR NAVBAR BUTTON ALIGNMENT)
# --------------------------------------------------

st.markdown("""
<style>

.stApp {
    background-color: #f5faf7;
}

.block-container {
    padding-top: 2rem;
    padding-left: 5%;
    padding-right: 5%;
}

/* Compact Logo styling to fit with buttons */
.logo-title {
    color: #0b5d3b;
    font-size: 24px;
    font-weight: bold;
    margin-top: 5px;
}

/* Force buttons to align properly in navigation header */
div[data-testid="column"] {
    display: flex;
    align-items: center;
    justify-content: center;
}

div[data-testid="column"] button {
    white-space: nowrap !important;
    width: 100% !important;
    padding: 8px 10px !important;
    font-size: 15px !important;
    margin-top: 0px !important;
}

/* Hero Section */
.hero {
    background: linear-gradient(135deg, #075e3b, #198754);
    padding: 50px 30px;
    border-radius: 20px;
    text-align: center;
    color: white;
    margin-top: 10px;
    margin-bottom: 25px;
}

.hero-title {
    font-size: 38px;
    font-weight: bold;
}

.hero-text {
    font-size: 18px;
    margin-top: 15px;
}

/* Cards */
.card {
    background-color: white;
    padding: 20px;
    border-radius: 15px;
    border: 1px solid #dce8df;
    box-shadow: 0 4px 12px rgba(0,0,0,0.04);
    margin-bottom: 15px;
}

/* Form box */
.form-box {
    background-color: white;
    padding: 25px;
    border-radius: 20px 20px 0 0;
    border: 1px solid #dce8df;
    border-bottom: none;
    box-shadow: 0 -5px 15px rgba(0,0,0,0.02);
}

.form-title {
    text-align: center;
    color: #0b5d3b;
    font-size: 30px;
    font-weight: bold;
}

.form-subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 10px;
}

/* Section */
.section-title {
    color: #145a32;
    font-size: 26px;
    font-weight: bold;
    margin-top: 25px;
    margin-bottom: 20px;
}

/* Footer */
.footer {
    background-color: #0b5d3b;
    color: white;
    padding: 25px;
    text-align: center;
    border-radius: 15px;
    margin-top: 50px;
}

</style>
""", unsafe_allow_html=True)


# ==================================================
# NAVBAR
# ==================================================

is_admin = st.session_state.user and st.session_state.user["role"] == "Admin"

# Wider proportions to accommodate full button labels
if is_admin:
    nav1, nav2, nav3, nav4, nav5, nav6 = st.columns([3, 1.5, 1.8, 1.8, 1.5, 1.5])
else:
    nav1, nav2, nav3, nav4, nav5 = st.columns([3, 1.5, 1.8, 1.5, 1.5])


with nav2:
    if st.button("🏠 Home", use_container_width=True, key="nav_home"):
        go_to("Home")

with nav3:
    if st.button("🛒 Marketplace", use_container_width=True, key="nav_market"):
        go_to("Marketplace")

if is_admin:
    with nav4:
        if st.button("🛡️ Admin Panel", use_container_width=True, key="nav_admin"):
            go_to("Admin")
    with nav5:
        st.write(f"👑 **{st.session_state.user['name']}**")
    with nav6:
        if st.button("🚪 Logout", use_container_width=True, key="nav_logout"):
            logout()
elif st.session_state.user:
    with nav4:
        st.write(f"👋 **{st.session_state.user['name']}**")
    with nav5:
        if st.button("🚪 Logout", use_container_width=True, key="nav_logout"):
            logout()
else:
    with nav4:
        if st.button("🔐 Login", use_container_width=True, key="nav_login"):
            go_to("Login")
    with nav5:
        if st.button("📝 Register", use_container_width=True, key="nav_register"):
            go_to("Register")


# ==================================================
# HOME PAGE
# ==================================================

if st.session_state.page == "Home":

    if st.session_state.user:
        st.success(f"Welcome back, **{st.session_state.user['name']}**! (Village: {st.session_state.user['village']} | Role: {st.session_state.user['role']})")

    st.markdown("""
    <div class="hero">
        <div class="hero-title">
            Smart Village Resource Sharing Portal
        </div>
        <div class="hero-text">
            Connect with your community, share useful resources, and easily find what you need.
        </div>
    </div>
    """, unsafe_allow_html=True)

    if not st.session_state.user:
        c1, c2, c3, c4 = st.columns([2, 1, 1, 2])
        
    st.markdown('<div class="section-title">🌱 About Our Portal</div>', unsafe_allow_html=True)
    st.write(
        "Smart Village Resource Sharing Portal is a community-based platform that allows villagers "
        "to share and access useful resources such as farming equipment, vehicles, books, and tools."
    )

    st.markdown('<div class="section-title">📦 Resources You Can Share</div>', unsafe_allow_html=True)
    r1, r2, r3, r4 = st.columns(4)

    with r1:
        st.markdown("""
        <div class="card" style="text-align: center;">
            <h2>🚜</h2>
            <h3>Farming</h3>
            <p>Tractors, pumps, and farming equipment.</p>
        </div>
        """, unsafe_allow_html=True)

    with r2:
        st.markdown("""
        <div class="card" style="text-align: center;">
            <h2>🚗</h2>
            <h3>Vehicles</h3>
            <p>Vehicles and transportation resources.</p>
        </div>
        """, unsafe_allow_html=True)

    with r3:
        st.markdown("""
        <div class="card" style="text-align: center;">
            <h2>📚</h2>
            <h3>Books</h3>
            <p>Educational books and study materials.</p>
        </div>
        """, unsafe_allow_html=True)

    with r4:
        st.markdown("""
        <div class="card" style="text-align: center;">
            <h2>🔧</h2>
            <h3>Tools</h3>
            <p>Tools and equipment for community sharing.</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown('<div class="section-title">⚙️ How It Works</div>', unsafe_allow_html=True)
    h1, h2, h3, h4 = st.columns(4)

    with h1:
        st.info("👤 **1. Register**\n\nCreate your account.")
    with h2:
        st.info("🔎 **2. Search**\n\nFind a resource.")
    with h3:
        st.info("📩 **3. Request**\n\nSend a request.")
    with h4:
        st.info("🤝 **4. Share**\n\nGet the resource.")


# ==================================================
# MARKETPLACE PAGE
# ==================================================

elif st.session_state.page == "Marketplace":

    st.markdown('<div class="section-title">🛒 Resource Marketplace</div>', unsafe_allow_html=True)

    tab1, tab2 = st.tabs(["🔎 Browse Resources", "➕ Add New Listing"])

    with tab1:
        st.subheader("Available Community Resources")

        f1, f2 = st.columns(2)
        with f1:
            category_filter = st.selectbox("Filter by Category", ["All", "Farming", "Vehicles", "Books", "Tools", "Other"])
        with f2:
            village_filter = st.text_input("Filter by Village (leave blank for all)", placeholder="Enter village name")

        selected_village = village_filter.strip() if village_filter.strip() else "All"
        resources = get_resources(category_filter, selected_village)

        st.write("")

        if not resources:
            st.info("No available resources match your filter criteria.")
        else:
            for item in resources:
                item_id, title, category, village, desc, owner_name, owner_phone, status = item
                with st.container():
                    st.markdown(f"""
                    <div class="card">
                        <h3>📦 {title} <span style="font-size:14px; color:#198754; font-weight:normal;">({status})</span></h3>
                        <p><strong>Category:</strong> {category} | <strong>Village:</strong> {village}</p>
                        <p>{desc}</p>
                        <p><strong>Owner:</strong> {owner_name}</p>
                    </div>
                    """, unsafe_allow_html=True)

                    c_btn1, c_btn2 = st.columns([3, 1])
                    with c_btn1:
                        if st.session_state.user:
                            if st.button(f"📞 Contact Owner ({owner_name})", key=f"req_{item_id}"):
                                st.success(f"Contact details for **{owner_name}**: Phone - **{owner_phone}**")
                        else:
                            st.info("🔐 Please login to view contact details and request this item.")
                    
                    if is_admin:
                        with c_btn2:
                            if st.button("🗑️ Delete (Admin)", key=f"mkt_del_{item_id}", type="primary"):
                                delete_resource(item_id)
                                st.success("Item deleted.")
                                st.rerun()

                    st.write("---")

    with tab2:
        if not st.session_state.user:
            st.warning("🔒 You must be logged in to list a resource.")
            if st.button("🔐 Go to Login", key="mkt_login_redirect"):
                go_to("Login")
        else:
            st.subheader("Post a Resource for Community Sharing")

            with st.form("add_resource_form"):
                title = st.text_input("Resource Name / Title", placeholder="e.g. Water Pump 5HP / John Deere Tractor")
                category = st.selectbox("Category", ["Farming", "Vehicles", "Books", "Tools", "Other"])
                village = st.text_input("Village Location", value=st.session_state.user["village"])
                description = st.text_area("Description / Conditions", placeholder="Describe the item condition, availability terms, etc.")

                submit_item = st.form_submit_button("🚀 Post Listing", use_container_width=True)

                if submit_item:
                    if not title or not description or not village:
                        st.error("Please fill in all required fields.")
                    else:
                        add_resource(
                            owner_id=st.session_state.user["id"],
                            owner_name=st.session_state.user["name"],
                            owner_phone=st.session_state.user["phone"],
                            title=title,
                            category=category,
                            village=village,
                            description=description
                        )
                        st.success(f"🎉 '{title}' has been listed successfully!")


# ==================================================
# ADMIN DASHBOARD PAGE
# ==================================================

elif st.session_state.page == "Admin":

    if not is_admin:
        st.error("🚨 Access Denied! You must be logged in as an Admin to view this page.")
    else:
        st.markdown('<div class="section-title">🛡️ Admin Dashboard</div>', unsafe_allow_html=True)

        admin_tab1, admin_tab2 = st.tabs(["👥 Registered Accounts", "🗑️ Manage Resource Listings"])

        with admin_tab1:
            st.subheader("All Registered Users")
            all_users = get_all_users()

            if not all_users:
                st.info("No registered users found.")
            else:
                user_data = []
                for u in all_users:
                    user_data.append({
                        "ID": u[0],
                        "Name": u[1],
                        "Email": u[2],
                        "Phone": u[3],
                        "Village": u[4],
                        "Role": u[5]
                    })
                st.dataframe(user_data, use_container_width=True)

        with admin_tab2:
            st.subheader("Active Resource Listings Moderation")
            all_listings = get_resources()

            if not all_listings:
                st.info("No listings available in database.")
            else:
                for item in all_listings:
                    item_id, title, category, village, desc, owner_name, owner_phone, status = item
                    with st.container():
                        col_info, col_act = st.columns([4, 1])
                        with col_info:
                            st.markdown(f"**[{category}] {title}** — Posted by *{owner_name}* ({village})")
                            st.caption(f"Details: {desc}")
                        with col_act:
                            if st.button("🗑️ Delete", key=f"admin_del_{item_id}", type="primary"):
                                delete_resource(item_id)
                                st.success(f"Listing '{title}' deleted successfully!")
                                st.rerun()
                        st.write("---")


# ==================================================
# LOGIN PAGE
# ==================================================

elif st.session_state.page == "Login":

    left, middle, right = st.columns([1, 2, 1])

    with middle:
        st.markdown("""
        <div class="form-box">
            <div class="form-title">🔐 Login</div>
            <div class="form-subtitle">Login to your Smart Village account</div>
        </div>
        """, unsafe_allow_html=True)

        with st.form("login_form"):
            email = st.text_input("Email Address", placeholder="Enter your email")
            password = st.text_input("Password", type="password", placeholder="Enter your password")
            submit = st.form_submit_button("🔐 Login", use_container_width=True)

            if submit:
                if not email or not password:
                    st.error("Please enter both email and password.")
                else:
                    user = authenticate_user(email, password)
                    if user:
                        st.session_state.user = {
                            "id": user[0],
                            "name": user[1],
                            "email": user[2],
                            "phone": user[3],
                            "role": user[4],
                            "village": user[5]
                        }
                        st.success(f"Welcome back, {user[1]}! 🎉")
                        go_to("Marketplace")
                    else:
                        st.error("Invalid email or password.")

        st.write("")
        st.write("Don't have an account?")
        if st.button("Create New Account", use_container_width=True, key="go_to_reg"):
            go_to("Register")


# ==================================================
# REGISTER PAGE
# ==================================================

elif st.session_state.page == "Register":

    left, middle, right = st.columns([1, 2, 1])

    with middle:
        st.markdown("""
        <div class="form-box">
            <div class="form-title">📝 Create Account</div>
            <div class="form-subtitle">Join the Smart Village community</div>
        </div>
        """, unsafe_allow_html=True)

        with st.form("register_form"):
            name = st.text_input("Full Name", placeholder="Enter your full name")
            email = st.text_input("Email Address", placeholder="Enter your email")
            phone = st.text_input("Phone Number", placeholder="Enter your phone number")
            village = st.text_input("Village", placeholder="Enter your village")
            password = st.text_input("Password", type="password", placeholder="Create a password")
            confirm_password = st.text_input("Confirm Password", type="password", placeholder="Confirm your password")
            role = st.selectbox("Register As", ["User", "Admin"])
            agree = st.checkbox("I agree to the terms and conditions")

            submit = st.form_submit_button("📝 Create Account", use_container_width=True)

            if submit:
                if not name:
                    st.error("Please enter your name.")
                elif not email:
                    st.error("Please enter your email.")
                elif not phone:
                    st.error("Please enter your phone number.")
                elif not village:
                    st.error("Please enter your village.")
                elif not password:
                    st.error("Please create a password.")
                elif password != confirm_password:
                    st.error("Passwords do not match.")
                elif not agree:
                    st.error("Please agree to the terms and conditions.")
                else:
                    success, message = register_user(name, email, phone, village, password, role)
                    if success:
                        st.success(message)
                        go_to("Login")
                    else:
                        st.error(message)

        st.write("")
        st.write("Already have an account?")
        if st.button("🔐 Login Here", use_container_width=True, key="go_to_login"):
            go_to("Login")


# ==================================================
# FOOTER
# ==================================================

st.markdown("""
<div class="footer">
    <h3>🌾 Smart Village Resource Sharing Portal</h3>
    <p>Building stronger communities through technology and resource sharing.</p>
    <p>© 2026 Smart Village</p>
</div>
""", unsafe_allow_html=True)



# database

import streamlit as st
import mysql.connector

# Connect to MySQL Database
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",  # Replace with your actual password
        database="smart_village"
    )

st.title("Smart Village Resource Sharing Portal")

# Fetch and Display Users
try:
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    
    st.subheader("Registered Users")
    st.dataframe(users)
    
    cursor.close()
    conn.close()
except Exception as e:
    st.error(f"Error connecting to database: {e}")

    #data
    import sqlite3
import streamlit as st

# 1. Database Connection Function
def get_connection():
    return sqlite3.connect("smart_village.db", check_same_thread=False)

# 2. Initialize Database and Create Table
def init_db():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Run initialization on startup
init_db()

st.title("Smart Village Resource Sharing Portal")

# 3. Registration Form (Auto-Saves to Database)
st.subheader("Register New User")

with st.form(key="user_form", clear_on_submit=True):
    name = st.text_input("Full Name")
    contact_info = st.text_input("Email / Phone Number")
    role = st.selectbox("Role", ["Villager", "Farmer", "Panchayat Member", "Admin"])
    
    submit_button = st.form_submit_button("Register User")

if submit_button:
    if name.strip() and contact_info.strip():
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO users (name, contact_info, role) VALUES (?, ?, ?)",
                (name, contact_info, role)
            )
            conn.commit()
            conn.close()
            st.success(f"Successfully saved {name} to database!")
            st.rerun()
        except Exception as e:
            st.error(f"Database Error: {e}")
    else:
        st.warning("Please fill in both Name and Contact Info.")

# 4. Fetch and Display Stored Users
st.divider()
st.subheader("Registered Users")

try:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, phone, role FROM users")
    rows = cursor.fetchall()
    conn.close()

    if rows:
        # Transform SQL rows into a list of dictionaries for Streamlit display
        data = [
            {"ID": r[0], "Name": r[1], "Contact": r[2], "Role": r[3]} 
            for r in rows
        ]
        st.dataframe(data, use_container_width=True)
    else:
        st.info("No registered users found in the database.")
except Exception as e:
    st.error(f"Error reading database: {e}")

def create_admin():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    admin_email = "admin@smartvillage.com"

    c.execute(
        "SELECT id FROM users WHERE email = ?",
        (admin_email,)
    )

    existing = c.fetchone()

    if not existing:
        c.execute("""
            INSERT INTO users
            (name, email, phone, village, password, role)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            "Smart Village Admin",
            "admin@smartvillage.com",
            "9999999999",
            "Smart Village",
            hash_password("admin123"),
            "Admin"
        ))

        conn.commit()

    conn.close()

    # Initialize database
init_db()

# Create admin account
create_admin()


def get_all_users():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()

    c.execute("""
        SELECT id, name, email, phone, village, role
        FROM users
        ORDER BY id DESC
    """)

    users = c.fetchall()
    conn.close()
    return users

    all_users = get_all_users()

    